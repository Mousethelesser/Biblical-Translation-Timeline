Biblical Manuscripts Timeline — PWA
===================================

Files:
- index.html
- app.webmanifest
- sw.js
- icons/

How to use on iPhone/iPad (iOS):
1) Host these files over HTTPS (GitHub Pages / Netlify / Vercel etc.).
2) Open the URL in Safari.
3) Share -> Add to Home Screen.
4) Launch from the Home Screen icon for full-screen app mode.
5) For updates, edit files and bump CACHE_VERSION in sw.js, redeploy, then open the app while online.

For personal use only.
